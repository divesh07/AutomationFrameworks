package common.services;

import java.util.Iterator;

import javax.ws.rs.core.Response;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import common.actions.Constants;
import common.actions.Util;
import cucumber.api.java.en.Given;

public class LiveQueryService {

    private static final Logger LOG = LoggerFactory.getLogger(LiveQueryService.class);


}
